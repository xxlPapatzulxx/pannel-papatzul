

$(document).ready(function(){
   $('body').scrollspy({ target: '#sidebar-page-navigation' });
});
