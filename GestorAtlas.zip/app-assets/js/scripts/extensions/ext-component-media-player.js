/*=========================================================================================
    File Name: ext-component-media-player.js
    Description:extra components media player using Plyr plugin
    --------------------------------------------------------------------------------------
    Item Name: Atlas Painel
    Version: 1.0
    Author: Atlas
    Author URL: https://api.painelpro.shop
==========================================================================================*/
$(document).ready(function () {
  // video player  define
  var player = new Plyr(".video-player");
  // audio player define
  var player1 = new Plyr(".audio-player");
});
