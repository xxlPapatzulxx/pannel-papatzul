#!/bin/sh
curl —silent https://painelpro.shop/onlines.php >/dev/null 2>&1 && curl —silent https://painelpro.shop.xyz/checkpag.php >/dev/null 2>&1