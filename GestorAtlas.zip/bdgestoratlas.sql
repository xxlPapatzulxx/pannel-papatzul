-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 18/03/2024 às 13:18
-- Versão do servidor: 10.6.17-MariaDB
-- Versão do PHP: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `gestoratlas`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `contato` varchar(255) DEFAULT NULL,
  `login` varchar(50) NOT NULL DEFAULT '0',
  `token` varchar(330) NOT NULL DEFAULT '0',
  `mb` varchar(50) NOT NULL DEFAULT '0',
  `senha` varchar(50) NOT NULL DEFAULT '0',
  `byid` varchar(50) NOT NULL DEFAULT '0',
  `mainid` varchar(50) NOT NULL DEFAULT '0',
  `accesstoken` text DEFAULT NULL,
  `valorusuario` varchar(50) DEFAULT NULL,
  `valorrevenda` varchar(50) DEFAULT NULL,
  `idtelegram` text DEFAULT NULL,
  `tempo` text DEFAULT NULL,
  `tokenvenda` text NOT NULL DEFAULT '0',
  `acesstokenpaghiper` text DEFAULT NULL,
  `formadepag` text DEFAULT NULL,
  `tokenpaghiper` text DEFAULT NULL,
  `whatsapp` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `accounts`
--

INSERT INTO `accounts` (`id`, `nome`, `contato`, `login`, `token`, `mb`, `senha`, `byid`, `mainid`, `accesstoken`, `valorusuario`, `valorrevenda`, `idtelegram`, `tempo`, `tokenvenda`, `acesstokenpaghiper`, `formadepag`, `tokenpaghiper`, `whatsapp`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', '60', '12345', '0', 'mainiduser', NULL, '0', '0', NULL, '1', '0', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `atlasdeviceid`
--

CREATE TABLE `atlasdeviceid` (
  `id` int(11) NOT NULL,
  `nome_user` varchar(255) DEFAULT NULL,
  `deviceid` varchar(255) DEFAULT NULL,
  `byid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `atribuidos`
--

CREATE TABLE `atribuidos` (
  `id` int(11) NOT NULL,
  `valor` varchar(255) DEFAULT NULL,
  `categoriaid` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL DEFAULT 0,
  `byid` int(11) NOT NULL DEFAULT 0,
  `limite` int(11) NOT NULL DEFAULT 0,
  `limitetest` int(11) DEFAULT NULL,
  `tipo` text NOT NULL,
  `expira` text DEFAULT NULL,
  `subrev` int(11) NOT NULL DEFAULT 0,
  `suspenso` int(11) NOT NULL DEFAULT 0,
  `valormensal` text DEFAULT NULL,
  `notificado` text DEFAULT 'nao'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `bot`
--

CREATE TABLE `bot` (
  `id` int(6) UNSIGNED NOT NULL,
  `app` text DEFAULT NULL,
  `sender` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `idpagamento` text DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `quantidadeuser` text DEFAULT NULL,
  `status` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `subid` int(11) DEFAULT NULL,
  `nome` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `configs`
--

CREATE TABLE `configs` (
  `id` int(6) UNSIGNED NOT NULL,
  `nomepainel` text DEFAULT NULL,
  `logo` text DEFAULT NULL,
  `icon` text DEFAULT NULL,
  `corborder` text DEFAULT NULL,
  `corletranav` text DEFAULT NULL,
  `deviceativo` text DEFAULT NULL,
  `imglogin` text DEFAULT NULL,
  `corbarranav` text DEFAULT NULL,
  `corfundologo` text DEFAULT NULL,
  `corcard` text DEFAULT NULL,
  `cortextcard` text DEFAULT NULL,
  `cornavsuperior` text DEFAULT NULL,
  `minimocompra` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `configs`
--

INSERT INTO `configs` (`id`, `nomepainel`, `logo`, `icon`, `corborder`, `corletranav`, `deviceativo`, `imglogin`, `corbarranav`, `corfundologo`, `corcard`, `cortextcard`, `cornavsuperior`, `minimocompra`) VALUES
(1, 'Atlas Painel', 'https://cdn.discordapp.com/attachments/1051302877987086437/1070581060821340250/logo.png', 'https://cdn.discordapp.com/attachments/1051302877987086437/1070581061014274088/logo-mini.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `cupons`
--

CREATE TABLE `cupons` (
  `id` int(6) UNSIGNED NOT NULL,
  `nome` varchar(30) NOT NULL,
  `cupom` varchar(50) NOT NULL,
  `desconto` varchar(50) NOT NULL,
  `usado` varchar(50) NOT NULL,
  `byid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT 0,
  `texto` text DEFAULT NULL,
  `validade` text DEFAULT NULL,
  `revenda` text DEFAULT NULL,
  `byid` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id` int(6) UNSIGNED NOT NULL,
  `funcao` text DEFAULT NULL,
  `mensagem` text DEFAULT NULL,
  `ativo` text DEFAULT NULL,
  `hora` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `onlines`
--

CREATE TABLE `onlines` (
  `id` int(6) UNSIGNED NOT NULL,
  `usuario` text NOT NULL,
  `quantidade` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamentos`
--

CREATE TABLE `pagamentos` (
  `id` int(11) NOT NULL,
  `idpagamento` varchar(50) DEFAULT NULL,
  `valor` varchar(50) DEFAULT NULL,
  `texto` text DEFAULT NULL,
  `iduser` varchar(50) DEFAULT NULL,
  `data` text DEFAULT NULL,
  `status` text DEFAULT NULL,
  `login` text DEFAULT NULL,
  `byid` varchar(50) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `tipo` text DEFAULT NULL,
  `addlimite` int(11) DEFAULT NULL,
  `formadepag` text DEFAULT '1',
  `tokenpaghiper` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `servidores`
--

CREATE TABLE `servidores` (
  `id` int(11) NOT NULL,
  `subid` int(11) NOT NULL DEFAULT 0,
  `nome` varchar(150) NOT NULL DEFAULT '0',
  `porta` int(11) NOT NULL DEFAULT 0,
  `usuario` varchar(150) NOT NULL DEFAULT '0',
  `senha` varchar(150) NOT NULL DEFAULT '0',
  `ip` varchar(150) NOT NULL DEFAULT '0',
  `servercpu` varchar(150) NOT NULL DEFAULT '0',
  `serverram` varchar(150) NOT NULL DEFAULT '0',
  `onlines` varchar(150) NOT NULL DEFAULT '0',
  `lastview` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ssh_accounts`
--

CREATE TABLE `ssh_accounts` (
  `id` int(11) NOT NULL,
  `byid` int(11) NOT NULL DEFAULT 0,
  `categoriaid` int(11) NOT NULL DEFAULT 0,
  `limite` int(11) NOT NULL DEFAULT 0,
  `bycredit` int(11) NOT NULL DEFAULT 0,
  `login` varchar(50) NOT NULL DEFAULT '0',
  `senha` varchar(50) NOT NULL DEFAULT '0',
  `mainid` text NOT NULL,
  `expira` text DEFAULT NULL,
  `lastview` text DEFAULT NULL,
  `status` text DEFAULT NULL,
  `valormensal` text DEFAULT NULL,
  `notificado` text DEFAULT 'nao',
  `whatsapp` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `userlimiter`
--

CREATE TABLE `userlimiter` (
  `id` int(11) NOT NULL,
  `nome_user` varchar(255) DEFAULT NULL,
  `limiter` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `whatsapp`
--

CREATE TABLE `whatsapp` (
  `id` int(6) UNSIGNED NOT NULL,
  `token` text DEFAULT NULL,
  `sessao` text DEFAULT NULL,
  `ativo` text DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `atlasdeviceid`
--
ALTER TABLE `atlasdeviceid`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `atribuidos`
--
ALTER TABLE `atribuidos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `bot`
--
ALTER TABLE `bot`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `configs`
--
ALTER TABLE `configs`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cupons`
--
ALTER TABLE `cupons`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `onlines`
--
ALTER TABLE `onlines`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `servidores`
--
ALTER TABLE `servidores`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `ssh_accounts`
--
ALTER TABLE `ssh_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `userlimiter`
--
ALTER TABLE `userlimiter`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `whatsapp`
--
ALTER TABLE `whatsapp`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `atlasdeviceid`
--
ALTER TABLE `atlasdeviceid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `atribuidos`
--
ALTER TABLE `atribuidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `bot`
--
ALTER TABLE `bot`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `configs`
--
ALTER TABLE `configs`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cupons`
--
ALTER TABLE `cupons`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `onlines`
--
ALTER TABLE `onlines`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pagamentos`
--
ALTER TABLE `pagamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `servidores`
--
ALTER TABLE `servidores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `ssh_accounts`
--
ALTER TABLE `ssh_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `userlimiter`
--
ALTER TABLE `userlimiter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `whatsapp`
--
ALTER TABLE `whatsapp`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
