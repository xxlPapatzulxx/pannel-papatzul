<?php


session_start();
include "atlas/conexao.php";
try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
} catch (mysqli_sql_exception $ex) {
    echo "<script>window.location.href = 'install.php';</script>";
}
$sql = "CREATE TABLE IF NOT EXISTS `accounts` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `nome` varchar(255) DEFAULT NULL,\r\n    `contato` varchar(255) DEFAULT NULL,\r\n    `login` varchar(50) NOT NULL DEFAULT '0',\r\n    `token` varchar(330) NOT NULL DEFAULT '0',\r\n    `mb` varchar(50) NOT NULL DEFAULT '0',\r\n    `senha` varchar(50) NOT NULL DEFAULT '0',\r\n    `byid` varchar(50) NOT NULL DEFAULT '0',\r\n    `mainid` varchar(50) NOT NULL DEFAULT '0',\r\n    `accesstoken` text DEFAULT NULL,\r\n    `valorusuario` varchar(50) DEFAULT NULL,\r\n    `valorrevenda` varchar(50) DEFAULT NULL,\r\n    `idtelegram` text DEFAULT NULL,\r\n    `tempo` text DEFAULT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
$result = mysqli_query($conn, $sql);
$sql2 = "INSERT INTO `accounts` (`id`, `nome`, `contato`, `login`, `token`, `mb`, `senha`, `byid`, `mainid`, `accesstoken`, `valorusuario`, `valorrevenda`) VALUES\r\n(1, 'admin', 'admin', 'admin', 'admin', '60', '12345', '0', '0', NULL, '0', '0');";
$result2 = mysqli_query($conn, $sql2);
$sql44 = "CREATE TABLE IF NOT EXISTS `atlasdeviceid` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `nome_user` varchar(255) DEFAULT NULL,\r\n    `deviceid` varchar(255) DEFAULT NULL,\r\n    `byid` int(11) DEFAULT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
$result44 = mysqli_query($conn, $sql44);
$sql3 = "CREATE TABLE IF NOT EXISTS `atribuidos` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `valor` varchar(255) DEFAULT NULL,\r\n    `categoriaid` int(11) NOT NULL DEFAULT 0,\r\n    `userid` int(11) NOT NULL DEFAULT 0,\r\n    `byid` int(11) NOT NULL DEFAULT 0,\r\n    `limite` int(11) NOT NULL DEFAULT 0,\r\n    `limitetest` int(11) DEFAULT NULL,\r\n    `tipo` text NOT NULL,\r\n    `expira` text DEFAULT NULL,\r\n    `subrev` int(11) NOT NULL DEFAULT 0,\r\n    `suspenso` int(11) NOT NULL DEFAULT 0,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;\r\n    ";
$result3 = mysqli_query($conn, $sql3);
$sql4 = "CREATE TABLE IF NOT EXISTS `categorias` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `subid` int(11) DEFAULT NULL,\r\n    `nome` varchar(150) DEFAULT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
$result4 = mysqli_query($conn, $sql4);
$sql55 = "CREATE TABLE IF NOT EXISTS `configs` (\r\n    `id` int(6) unsigned NOT NULL AUTO_INCREMENT,\r\n    `nomepainel` text DEFAULT NULL,\r\n    `logo` text DEFAULT NULL,\r\n    `icon` text DEFAULT NULL,\r\n    `corborder` text DEFAULT NULL,\r\n    `corletranav` text DEFAULT NULL,\r\n    `deviceativo` text DEFAULT NULL,\r\n    `imglogin` text DEFAULT NULL,\r\n    `corbarranav` text DEFAULT NULL,\r\n    `corfundologo` text DEFAULT NULL,\r\n    `corcard` text DEFAULT NULL,\r\n    `cortextcard` text DEFAULT NULL,\r\n    `cornavsuperior` text DEFAULT NULL,\r\n    `minimocompra` text DEFAULT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;\r\n  ";
$result55 = mysqli_query($conn, $sql55);
$sql45 = "CREATE TABLE IF NOT EXISTS `cupons` (\r\n    `id` int(6) unsigned NOT NULL AUTO_INCREMENT,\r\n    `nome` varchar(30) NOT NULL,\r\n    `cupom` varchar(50) NOT NULL,\r\n    `desconto` varchar(50) NOT NULL,\r\n    `usado` varchar(50) NOT NULL,\r\n    `byid` varchar(50) NOT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;\r\n  ";
$result45 = mysqli_query($conn, $sql45);
$sql22 = "INSERT INTO `configs` (`id`, `nomepainel`, `logo`, `icon`) VALUES\r\n    (1, 'Atlas Painel', 'https://cdn.discordapp.com/attachments/1051302877987086437/1070581060821340250/logo.png', 'https://cdn.discordapp.com/attachments/1051302877987086437/1070581061014274088/logo-mini.png');";
$result22 = mysqli_query($conn, $sql22);
$sql5 = "CREATE TABLE IF NOT EXISTS `logs` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `userid` int(11) DEFAULT 0,\r\n    `texto` text DEFAULT NULL,\r\n    `validade` text DEFAULT NULL,\r\n    `revenda` text DEFAULT NULL,\r\n    `byid` text DEFAULT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
$result5 = mysqli_query($conn, $sql5);
$sql98 = "CREATE TABLE IF NOT EXISTS `onlines` (\r\n    `id` int(6) unsigned NOT NULL AUTO_INCREMENT,\r\n    `usuario` text NOT NULL,\r\n    `quantidade` text NOT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
$result98 = mysqli_query($conn, $sql98);
$sql6 = "CREATE TABLE IF NOT EXISTS `pagamentos` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `idpagamento` varchar(50) DEFAULT NULL,\r\n    `valor` varchar(50) DEFAULT NULL,\r\n    `texto` text DEFAULT NULL,\r\n    `iduser` varchar(50) DEFAULT NULL,\r\n    `data` text DEFAULT NULL,\r\n    `status` text DEFAULT NULL,\r\n    `login` text DEFAULT NULL,\r\n    `byid` varchar(50) DEFAULT NULL,\r\n    `access_token` text DEFAULT NULL,\r\n    `tipo` text DEFAULT NULL,\r\n    `addlimite` int(11) DEFAULT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
$result6 = mysqli_query($conn, $sql6);
$sql7 = "CREATE TABLE IF NOT EXISTS `servidores` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `subid` int(11) NOT NULL DEFAULT 0,\r\n    `nome` varchar(150) NOT NULL DEFAULT '0',\r\n    `porta` int(11) NOT NULL DEFAULT 0,\r\n    `usuario` varchar(150) NOT NULL DEFAULT '0',\r\n    `senha` varchar(150) NOT NULL DEFAULT '0',\r\n    `ip` varchar(150) NOT NULL DEFAULT '0',\r\n    `servercpu` varchar(150) NOT NULL DEFAULT '0',\r\n    `serverram` varchar(150) NOT NULL DEFAULT '0',\r\n    `onlines` varchar(150) NOT NULL DEFAULT '0',\r\n    `lastview` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
$result7 = mysqli_query($conn, $sql7);
$sql32 = "CREATE TABLE IF NOT EXISTS `userlimiter` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `nome_user` varchar(255) DEFAULT NULL,\r\n    `limiter` varchar(255) DEFAULT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
$result32 = mysqli_query($conn, $sql32);
$sql8 = "CREATE TABLE IF NOT EXISTS `ssh_accounts` (\r\n    `id` int(11) NOT NULL AUTO_INCREMENT,\r\n    `byid` int(11) NOT NULL DEFAULT 0,\r\n    `categoriaid` int(11) NOT NULL DEFAULT 0,\r\n    `limite` int(11) NOT NULL DEFAULT 0,\r\n    `bycredit` int(11) NOT NULL DEFAULT 0,\r\n    `login` varchar(50) NOT NULL DEFAULT '0',\r\n    `senha` varchar(50) NOT NULL DEFAULT '0',\r\n    `mainid` text NOT NULL,\r\n    `expira` text DEFAULT NULL,\r\n    `lastview` text DEFAULT NULL,\r\n    `status` text DEFAULT NULL,\r\n    PRIMARY KEY (`id`)\r\n  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;";
if ($result8 = mysqli_query($conn, $sql8)) {
    echo "<script>alert('Instalado com sucesso!');</script><script>window.location.href = 'index.php';</script>";
} else {
    echo "<script>alert('Erro ao instalar!');</script>";
}

?>