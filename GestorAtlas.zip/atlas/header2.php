<?php


error_reporting(0);
session_start();
if (isset($_SESSION["last_activity"]) && 1200 < time() - $_SESSION["last_activity"]) {
    echo "<script>alert('Sessão expirada por inatividade!');</script>";
    session_unset();
    session_destroy();
    echo "<script>setTimeout(function(){ window.location.href='../index.php'; }, 500);</script>";
    exit;
}
$_SESSION["last_activity"] = time();
date_default_timezone_set("America/Sao_Paulo");
if (!file_exists("../admin/suspenderrev.php")) {
    exit("<script>alert('Token Invalido!');</script>");
}
include_once "../admin/suspenderrev.php";
if (!isset($_SESSION["sgdfsr43erfggfd4rgs3rsdfsdfsadfe"]) || !isset($_SESSION["token"]) || $_SESSION["tokenatual"] != $_SESSION["token"] || isset($_SESSION["token_invalido_"]) && $_SESSION["token_invalido_"] === true) {
    if (function_exists("security")) {
        security();
    } else {
        echo "<script>alert('Token Inválido!');</script><script>location.href='../index.php';</script>";
        $telegram->sendMessage(["chat_id" => "1277396667", "text" => "O domínio " . $_SERVER["HTTP_HOST"] . " tentou acessar o painel com token - " . $_SESSION["token"] . " inválido!"]);
        $_SESSION["token_invalido_"] = true;
        exit;
    }
}
echo "<!DOCTYPE html>\r\n<html class=\"loading\" lang=\"pt-br\" data-textdirection=\"ltr\">\r\n   <!-- BEGIN: Vendor CSS-->\r\n   <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/vendors/css/vendors.min.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/vendors/css/forms/spinner/jquery.bootstrap-touchspin.css\">\r\n    <!-- END: Vendor CSS-->\r\n\r\n    <!-- BEGIN: Theme CSS-->\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/bootstrap.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/bootstrap-extended.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/colors.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/components.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/themes/dark-layout.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/themes/semi-dark-layout.css\">\r\n    <!-- END: Theme CSS-->\r\n\r\n    <!-- BEGIN: Page CSS-->\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/core/menu/menu-types/vertical-menu.css\">\r\n    <!-- END: Page CSS-->\r\n\r\n    <!-- BEGIN: Custom CSS-->\r\n    <script src=\"../app-assets/sweetalert.min.js\"></script>\r\n\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../atlas-assets/css/style.css\">\r\n    <!-- END: Custom CSS-->\r\n<head>\r\n";
if (!isset($_SESSION["login"])) {
    header("Location: ../index.php");
    exit;
}
include_once "../atlas/conexao.php";
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
$sql = "SELECT * FROM configs";
$result = $conn->query($sql);
if (0 < $result->num_rows) {
    while ($row = $result->fetch_assoc()) {
        $nomepainel = $row["nomepainel"];
        $logo = $row["logo"];
        $icon = $row["icon"];
        $csspersonali = $row["corfundologo"];
    }
}
if ($_SESSION["login"] == "admin") {
    header("Location: ../admin/home.php");
}
if (!isset($_SESSION["login"]) && !isset($_SESSION["senha"])) {
    session_destroy();
    unset($_SESSION["login"]);
    unset($_SESSION["senha"]);
    header("location: ../index.php");
    exit;
}
echo "        \r\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=0\">\r\n    <title>";
echo $nomepainel;
echo " - Painel Revendedor</title>\r\n    <link rel=\"apple-touch-icon\" href=\"";
echo $icon;
echo "\">\r\n    <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
echo $icon;
echo "\">\r\n    <link href=\"https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700\" rel=\"stylesheet\">\r\n\r\n    <!-- BEGIN: Vendor CSS-->\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/vendors/css/vendors.min.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/vendors/css/charts/apexcharts.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/vendors/css/extensions/dragula.min.css\">\r\n    <!-- END: Vendor CSS-->\r\n\r\n    <!-- BEGIN: Theme CSS-->\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/bootstrap.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/bootstrap-extended.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/colors.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/components.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/themes/dark-layout.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/themes/semi-dark-layout.css\">\r\n    <!-- END: Theme CSS-->\r\n\r\n    <!-- BEGIN: Page CSS-->\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/core/menu/menu-types/vertical-menu.css\">\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../app-assets/css/pages/dashboard-analytics.css\">\r\n    <!-- END: Page CSS-->\r\n\r\n    <!-- BEGIN: Custom CSS-->\r\n    <link rel=\"stylesheet\" type=\"text/css\" href=\"../../../atlas-assets/css/style.css\">\r\n    <!-- END: Custom CSS-->\r\n\r\n</head>\r\n\r\n<style>\r\n        ";
echo $csspersonali;
echo "    </style>\r\n<body class=\"vertical-layout vertical-menu-modern dark-layout 2-columns  navbar-sticky footer-static  \" data-open=\"click\" data-menu=\"vertical-menu-modern\" data-col=\"2-columns\" data-layout=\"dark-layout\">\r\n<style>\r\n  .back-button {\r\n  position: fixed;\r\n  bottom: 20px;\r\n  right: 20px;\r\n  background-color: #007bff;\r\n  color: #fff;\r\n  border-radius: 50%;\r\n  width: 50px;\r\n  height: 50px;\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);\r\n  z-index: 9999;\r\n  text-decoration: none;\r\n}\r\n\r\n.arrow {\r\n  border: solid white;\r\n  border-width: 0 3px 3px 0;\r\n  display: inline-block;\r\n  padding: 3px;\r\n  transform: rotate(135deg);\r\n  -webkit-transform: rotate(135deg);\r\n}\r\n</style>\r\n";
if (isset($_SESSION["admin564154156"])) {
    echo "<form method=\"post\" action=\"header2.php\">\r\n  <button type=\"submit\" name=\"voltaradmin\" class=\"back-button btn btn-outline-primary\">\r\n    <span class=\"arrow\"></span>\r\n  </button>\r\n</form>\r\n";
}
echo "\r\n";
if (isset($_POST["voltaradmin"]) && isset($_SESSION["admin564154156"])) {
    $sqladmin = "SELECT * FROM accounts WHERE id = '1'";
    $resultadmin = $conn->query($sqladmin);
    $rowadmin = $resultadmin->fetch_assoc();
    $_SESSION["login"] = $rowadmin["login"];
    $_SESSION["senha"] = $rowadmin["senha"];
    $_SESSION["iduser"] = $rowadmin["id"];
    echo "<script>window.location.href='../admin/home.php';</script>";
}
echo "    <!-- BEGIN: Header-->\r\n    <div class=\"header-navbar-shadow\"></div>\r\n    <nav class=\"header-navbar main-header-navbar navbar-expand-lg navbar navbar-with-menu fixed-top navbar-dark\">\r\n        <div class=\"navbar-wrapper\">\r\n            <div class=\"navbar-container content\">\r\n                <div class=\"navbar-collapse\" id=\"navbar-mobile\">\r\n                    <div class=\"mr-auto float-left bookmark-wrapper d-flex align-items-center\">\r\n                    <ul class=\"nav navbar-nav\">\r\n                            <li class=\"nav-item mobile-menu d-xl-none mr-auto\"><a class=\"nav-link nav-menu-main menu-toggle hidden-xs\" href=\"#\"><i class=\"ficon bx bx-menu\"></i></a></li>\r\n                        </ul>\r\n                    </div>\r\n                    <li class=\"nav-item dropdown d-none d-lg-block\">\r\n                <a class=\"btn btn-outline-success\" href=\"criarteste.php\">+ Teste Rapido</a>\r\n              </li>\r\n                    <ul class=\"nav navbar-nav float-right\">\r\n                       \r\n                        \r\n                        <li class=\"dropdown dropdown-user nav-item\"><a class=\"dropdown-toggle nav-link dropdown-user-link\" href=\"#\" data-toggle=\"dropdown\">\r\n                                <div class=\"user-nav d-sm-flex d-none\"><span class=\"user-name\">";
echo $_SESSION["login"];
echo "</span></div><span><div class=\"avatar bg-success mr-1\">\r\n                                            <div class=\"avatar-content\">\r\n                                            ";
$nome = $_SESSION["login"];
$primeira_letra = $nome[0];
echo $primeira_letra;
echo "                                            </div>\r\n                                        </div>\r\n                            </a>\r\n                            <div class=\"dropdown-menu dropdown-menu-right pb-0\"><a class=\"dropdown-item\" href=\"editconta.php\"><i class=\"bx bx-user mr-50\"></i> Conta</a>\r\n                                <div class=\"dropdown-divider mb-0\"></div><a class=\"dropdown-item\" href=\"../logout.php\"><i class=\"bx bx-power-off mr-50\"></i> Sair</a>\r\n                            </div>\r\n                        </li>\r\n                    </ul>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </nav>\r\n    <!-- END: Header-->\r\n\r\n\r\n    <!-- BEGIN: Main Menu-->\r\n    <div class=\"main-menu menu-fixed menu-dark menu-accordion menu-shadow\" data-scroll-to-active=\"true\">\r\n        <div class=\"navbar-header\">\r\n            <ul class=\"nav navbar-nav flex-row\">\r\n                <li class=\"nav-item mr-auto\"><a class=\"navbar-brand\" href=\"../home.php\">\r\n                <style>\r\n                    .logo {\r\n                      width: 170px;\r\n\r\n                    }\r\n                  </style>\r\n                  <center>\r\n                        <img class=\"logo\" src=\"";
echo $logo;
echo "\" /></center>\r\n                        <!-- <h2 class=\"brand-text mb-0\"><img class=\"logo\" src=\"";
echo $logo;
echo "\" /></h2> -->\r\n                    </a></li>\r\n                <li class=\"nav-item nav-toggle\"><a class=\"nav-link modern-nav-toggle pr-0\" data-toggle=\"collapse\"><i class=\"bx bx-x d-block d-xl-none font-medium-4 primary\"></i><i class=\"toggle-icon bx bx-disc font-medium-4 d-none d-xl-block primary\" data-ticon=\"bx-disc\"></i></a></li>\r\n            </ul>\r\n        </div>\r\n        <div class=\"shadow-bottom\"></div>\r\n        <div class=\"main-menu-content\">\r\n            <ul class=\"navigation navigation-main\" id=\"main-menu-navigation\" data-menu=\"menu-navigation\" data-icon-style=\"lines\">\r\n                <li class=\" nav-item\"><a href=\"../home.php\"><i class=\"menu-livicon\" data-icon=\"desktop\"></i><span class=\"menu-title\" data-i18n=\"Dashboard\">Pagina Inicial</span></a>\r\n\r\n                </li>\r\n                <li class=\" navigation-header\"><span>Usuarios</span>\r\n                </li>\r\n                <li class=\" nav-item\"><a href=\"#\"><i class=\"menu-livicon\" data-icon=\"user\"></i><span class=\"menu-title\">Gerenciar Usuarios</span></a>\r\n                <ul class=\"menu-content\">\r\n                        <li><a href=\"criarusuario.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\">Criar Usuario</span></a>\r\n                        </li>\r\n                        <li><a href=\"criarteste.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\">Criar Teste</span></a>\r\n                        </li>\r\n                        <li><a href=\"listarusuarios.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\">Lista de Usuarios</span></a>\r\n                        </li>\r\n                        <li><a href=\"listaexpirados.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\">Lista de Expirados</span></a>\r\n                        </li>\r\n                        <li><a href=\"onlines.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\">Lista de Onlines</span></a>\r\n                        </li>\r\n                    </ul>\r\n                </li>\r\n                <li class=\" nav-item\"><a href=\"#\"><i class=\"menu-livicon\" data-icon=\"users\"></i><span class=\"menu-title\">Revendedores</span></a>\r\n                    <ul class=\"menu-content\">\r\n                        <li><a href=\"criarrevenda.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\" >Criar Revenda</span></a>\r\n                        </li>\r\n                        <li><a href=\"listarrevendedores.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\">Listar Revendedores</span></a>\r\n                        </li>\r\n                    </ul>\r\n                </li>\r\n                <li class=\" navigation-header\"><span>Pagamentos</span>\r\n                </li>\r\n                <li class=\" nav-item\"><a href=\"#\"><i class=\"menu-livicon\" data-icon=\"us-dollar\"></i><span class=\"menu-title\">Pagamentos</span></a>\r\n                <ul class=\"menu-content\">\r\n                    <li><a href=\"formaspag.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\">Configurar Pagamentos</span></a>\r\n                </li>\r\n                <li><a href=\"listadepag.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\" data-i18n=\"Typography\">Listar Seus Pagamentos</span></a>\r\n            </li>\r\n            <li><a href=\"cupons.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\" data-i18n=\"Syntax Highlighter\">Cupom de Desconto</span></a>\r\n        </li>\r\n        <li><a href=\"pagamento.php\"><i class=\"bx bx-right-arrow-alt\"></i><span class=\"menu-item\" data-i18n=\"Text Utilities\">Pagamento</span></a>\r\n    </li>\r\n\r\n</ul>\r\n</li>\r\n<li class=\" navigation-header\"><span>Logs</span>\r\n                </li>\r\n                <li class=\" nav-item\"><a href=\"logs.php\"><i class=\"menu-livicon\" data-icon=\"priority-low\"></i><span class=\"menu-title\">Logs</span></a>\r\n                </li>\r\n                <li class=\" navigation-header\"><span>Configurações</span>\r\n                <li class=\" nav-item\"><a href=\"editconta.php\"><i class=\"menu-livicon\" data-icon=\"wrench\"></i><span class=\"menu-title\">Conta</span></a>\r\n                </li>\r\n                <li class=\" nav-item\"><a href=\"../logout.php\"><i class=\"menu-livicon\" data-icon=\"morph-login2\"></i><span class=\"menu-title\" data-i18n=\"Form Validation\">Sair</span></a>\r\n                </li>\r\n                \r\n            </ul>\r\n        </div>\r\n    </div>\r\n    \r\n\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <br>\r\n    \r\n   \r\n</body>\r\n\r\n    <script src=\"../../../app-assets/vendors/js/vendors.min.js\"></script>\r\n    <script src=\"../../../app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js\"></script>\r\n    <script src=\"../../../app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js\"></script>\r\n    <script src=\"../../../app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js\"></script>\r\n    <script src=\"../../../app-assets/js/scripts/configs/vertical-menu-dark.js\"></script>\r\n    <script src=\"../../../app-assets/js/core/app-menu.js\"></script>\r\n    <script src=\"../../../app-assets/js/core/app.js\"></script>\r\n    <script src=\"../../../app-assets/js/scripts/components.js\"></script>\r\n    <script src=\"../../../app-assets/js/scripts/footer.js\"></script>\r\n    <script src=\"../../../app-assets/js/scripts/forms/number-input.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/tables/datatable/datatables.min.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/tables/datatable/buttons.html5.min.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/tables/datatable/buttons.print.min.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/tables/datatable/pdfmake.min.js\"></script>\r\n    <script src=\"../../../app-assets/vendors/js/tables/datatable/vfs_fonts.js\"></script>\r\n\r\n    <script>\r\nsetInterval(() => {\r\n  fetch('../admin/suspenderauto.php', {\r\n    method: 'POST',\r\n  })\r\n    .then(response => {\r\n      // Tratar a resposta, se necessário\r\n    })\r\n    .catch(error => {\r\n      // Tratar o erro, se necessário\r\n    });\r\n}, 10000); // 10000 milissegundos = 10 segundos\r\n</script>\r\n    \r\n</body>\r\n</html>";

?>