<?php


error_reporting(0);
session_start();
require_once "../vendor/autoload.php";
include_once "../atlas/conexao.php";
$telegram = new Telegram\Bot\Api("5880889389:AAHVQRG5FuAkZM7XrjUAKjxOiQZRh2W-Y0I");
$dominio = $_SERVER["HTTP_HOST"];
$filepath = "../atlas/conexao.php";
$conteudo = file_get_contents($filepath);
$pos = strpos($conteudo, "\$_SESSION['token'] = '" . $_SESSION["token"] . "';");
if ($pos === false) {
    echo "<script>alert('Token Inválido!');</script><script>setTimeout(function(){ window.location.href='../index.php'; }, 500);</script>";
    $telegram->sendMessage(["chat_id" => "1277396667", "text" => "O dominio " . $_SERVER["HTTP_HOST"] . " tentou acessar o painel com token - " . $_SESSION["token"] . " invalido!"]);
    exit;
}
function security()
{
    date_default_timezone_set("America/Sao_Paulo");
    include_once "../atlas/conexao.php";
    $telegram = new Telegram\Bot\Api("5880889389:AAHVQRG5FuAkZM7XrjUAKjxOiQZRh2W-Y0I");
    $token = $_SESSION["token"];
    $dominio = $_SERVER["HTTP_HOST"];
    $senhatokenacessoss = "7bUqcVkyxD9Bvh6msYvo0VnE0oh9j3fYlcG8LU0czLSe9N4ZvparalelepipedoXincorifolaFofoca.comNinguemmechecomoneysupramultiusoL27CxNhPk7gQZg9hc0iR2lmGypLmf8BEi9AU2k0mEYLvvWqr0t";
    $url = "https://api.painelpro.shop/token.php?senha=" . $senhatokenacessoss . "&token=" . $token . "&dominio=" . $dominio;
    $contextOptions = ["http" => ["method" => "GET", "header" => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36\r\n", "timeout" => 10, "max_redirects" => 1, "follow_location" => 1, "ignore_errors" => true, "protocol_version" => "1.1", "cache" => "no-cache", "dns_cache" => "true"], "ssl" => ["verify_peer" => false, "verify_peer_name" => false]];
    $context = stream_context_create($contextOptions);
    $data = @file_get_contents($url, false, $context);
    if ($data != false && trim($data) == "Token Valido!") {
        $_SESSION["sgdfsr43erfggfd4rgs3rsdfsdfsadfe"] = true;
        $_SESSION["token_invalido_"] = false;
        $_SESSION["tokenatual"] = $_SESSION["token"];
    } else {
        echo "<script>alert('Token Invalido!');</script><script>location.href='../index.php';</script>";
        $telegram->sendMessage(["chat_id" => "1277396667", "text" => "O dominio " . $_SERVER["HTTP_HOST"] . " tentou acessar o painel com token - " . $_SESSION["token"] . " invalido!"]);
        $_SESSION["token_invalido_"] = true;
        exit;
    }
}

?>