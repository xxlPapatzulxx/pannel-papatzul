<?php


ignore_user_abort(true);
set_time_limit(0);
require_once "../vendor/autoload.php";
include "../atlas/conexao.php";
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    exit("Connection failed: " . mysqli_connect_error());
}
set_include_path(get_include_path() . PATH_SEPARATOR . "../lib2");
include "Net/SSH2.php";
date_default_timezone_set("America/Sao_Paulo");
$Dados_bot = mysqli_query($conn, "SELECT * FROM accounts WHERE login = 'admin'");
$Dados_bot = mysqli_fetch_array($Dados_bot);
$token = $Dados_bot["token"];
$telegram = new Telegram\Bot\Api($token);
header("Refresh: 1;");
$telegram->removeWebhook();
while (true) {
    $last_update_id = file_get_contents("last_update_id.txt");
    $updates = $telegram->getUpdates(["offset" => $last_update_id + 1]);
    foreach ($updates as $update) {
        $last_update_id = $update->getUpdateId();
        $chat_id = $update->getMessage()->getChat()->getId();
        if ($update->getMessage()->getText() == "/start") {
            $telegram->sendMessage(["chat_id" => $chat_id, "text" => "Olá, seja bem-vindo ao bot do Atlas! Para Iniciar digite /iniciar ."]);
        }
        if ($update->getMessage()->getText() == "/iniciar") {
            $telegram->sendMessage(["chat_id" => $chat_id, "text" => "👋 Bem-vindo ao Menu Atlas! Por favor, escolha uma opção abaixo: \n\n🚀 /criarteste - Cria um teste 1 Hora\n\n🚀 /criar - Cria uma conta 30 Dias\n\n🚀 /deletar - Deleta uma conta\n\n"]);
        }
        if ($update->getMessage()->getText() == "/criarteste") {
            $categorias = mysqli_query($conn, "SELECT * FROM categorias");
            $message = "Em qual categoria deseja criar a conta SSH?\n\n";
            while ($row = mysqli_fetch_array($categorias)) {
                $message .= "Categoria " . $row["subid"] . " - /criartestecategoria" . $row["subid"] . "\n";
            }
            $telegram->sendMessage(["chat_id" => $chat_id, "text" => $message]);
        }
        if (strpos($update->getMessage()->getText(), "/criartestecategoria") != false) {
            $categoria = str_replace("/criartestecategoria", "", $update->getMessage()->getText());
            $result = mysqli_query($conn, "SELECT id FROM categorias WHERE subid = '" . $categoria . "'");
            if (mysqli_num_rows($result) == 0) {
                $telegram->sendMessage(["chat_id" => $chat_id, "text" => "Categoria inválida."]);
            } else {
                $servidores = mysqli_query($conn, "SELECT * FROM servidores WHERE subid = '" . $categoria . "'");
                $servidor = mysqli_fetch_array($servidores);
                while ($row = mysqli_fetch_array($servidores)) {
                    $servidores[] = $row;
                }
                define("SCRIPT_PATH", "./atlasteste.sh");
                define("SSH_PORT", 22);
                function trySshConnection($ip, $porta, $usuario, $senha, $tentativas = 3, $intervalo = 2)
                {
                    $ssh = new Net_SSH2($ip, $porta);
                    for ($tentativaAtual = 1; !$ssh->login($usuario, $senha); $tentativaAtual++) {
                        if ($tentativas < $tentativaAtual) {
                            return false;
                        }
                        sleep($intervalo);
                        $ssh = new Net_SSH2($ip, $porta);
                    }
                    return $ssh;
                }
                $sucess_servers = [];
                $sucess = false;
                $usuariofin = substr(str_shuffle(str_repeat("abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
                $senhafin = substr(str_shuffle(str_repeat("abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
                $validadefin = "60";
                $limitefin = "1";
                foreach ($servidores as $servidor) {
                    $ssh = trySshConnection($servidor["ip"], SSH_PORT, $servidor["usuario"], $servidor["senha"]);
                    if ($ssh) {
                        $ssh->exec(SCRIPT_PATH . " " . $usuariofin . " " . $senhafin . " " . $validadefin . " " . $limitefin . " > /dev/null 2>&1 &");
                        $sucess_servers[] = $servidor["nome"];
                        $sucess = true;
                        $ssh->disconnect();
                    } else {
                        $failed_servers[] = $servidor["nome"];
                    }
                }
                if ($sucess) {
                    $validadefin = date("Y-m-d H:i:s", strtotime("+" . $validadefin . " minutes"));
                    $sql_conta = "INSERT INTO ssh_accounts (login, senha, expira, limite, byid, categoriaid, lastview, bycredit, mainid, status) VALUES ('" . $usuariofin . "', '" . $senhafin . "', '" . $validadefin . "', '" . $limitefin . "', '1', '" . $categoria . "', '', '0', 'NULL', 'Offline')";
                    $result = mysqli_query($conn, $sql_conta);
                }
                $telegram->sendMessage(["chat_id" => $chat_id, "text" => "✅ Conta criada com sucesso! \n\n" . "👤 Usuário: " . $usuariofin . " \n" . "🔑 Senha: " . $senhafin . " \n" . "⏰ Validade: " . $validadefin . " \n" . "💻 Limite: " . $limitefin . " \n" . "🖥️ Servidores Criados: " . implode(", ", $sucess_servers) . "\n"]);
            }
        }
        if ($update->getMessage()->getText() == "/criar") {
            $categorias = mysqli_query($conn, "SELECT * FROM categorias");
            $message = "Em qual categoria deseja criar a conta SSH?\n\n";
            while ($row = mysqli_fetch_array($categorias)) {
                $message .= "Categoria " . $row["subid"] . " - /criarcontacategoria" . $row["subid"] . "\n";
            }
            $telegram->sendMessage(["chat_id" => $chat_id, "text" => $message]);
        }
        if (strpos($update->getMessage()->getText(), "/criarcontacategoria") != false) {
            $categoria = str_replace("/criarcontacategoria", "", $update->getMessage()->getText());
            $result = mysqli_query($conn, "SELECT id FROM categorias WHERE subid = '" . $categoria . "'");
            if (mysqli_num_rows($result) == 0) {
                $telegram->sendMessage(["chat_id" => $chat_id, "text" => "Categoria inválida."]);
            } else {
                $servidores = mysqli_query($conn, "SELECT * FROM servidores WHERE subid = '" . $categoria . "'");
                $servidor = mysqli_fetch_array($servidores);
                while ($row = mysqli_fetch_array($servidores)) {
                    $servidores[] = $row;
                }
                define("SCRIPT_PATH", "./atlascreate.sh");
                define("SSH_PORT", 22);
                function trySshConnection($ip, $porta, $usuario, $senha, $tentativas = 3, $intervalo = 2)
                {
                    $ssh = new Net_SSH2($ip, $porta);
                    for ($tentativaAtual = 1; !$ssh->login($usuario, $senha); $tentativaAtual++) {
                        if ($tentativas < $tentativaAtual) {
                            return false;
                        }
                        sleep($intervalo);
                        $ssh = new Net_SSH2($ip, $porta);
                    }
                    return $ssh;
                }
                $usuariofin = substr(str_shuffle(str_repeat("abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
                $senhafin = substr(str_shuffle(str_repeat("abcdefghijklmnopqrstuvwxyz", 5)), 0, 5);
                $validadefin = "30";
                $limitefin = "1";
                foreach ($servidores as $servidor) {
                    $ssh = trySshConnection($servidor["ip"], SSH_PORT, $servidor["usuario"], $servidor["senha"]);
                    if ($ssh) {
                        $ssh->exec(SCRIPT_PATH . " " . $usuariofin . " " . $senhafin . " " . $validadefin . " " . $limitefin . " > /dev/null 2>&1 &");
                        $sucess_servers[] = $servidor["nome"];
                        $sucess = true;
                        $ssh->disconnect();
                    } else {
                        $failed_servers[] = $servidor["nome"];
                    }
                }
                if ($sucess) {
                    $validadefin = date("Y-m-d H:i:s", strtotime("+" . $validadefin . " days"));
                    $sql_conta = "INSERT INTO ssh_accounts (login, senha, expira, limite, byid, categoriaid, lastview, bycredit, mainid, status) VALUES ('" . $usuariofin . "', '" . $senhafin . "', '" . $validadefin . "', '" . $limitefin . "', '1', '" . $categoria . "', '', '0', 'NULL', 'Offline')";
                    $result = mysqli_query($conn, $sql_conta);
                }
                $telegram->sendMessage(["chat_id" => $chat_id, "text" => "✅ Conta criada com sucesso! \n\n" . "👤 Usuário: " . $usuariofin . " \n" . "🔑 Senha: " . $senhafin . " \n" . "⏰ Validade: " . $validadefin . " \n" . "💻 Limite: " . $limitefin . " \n" . "🖥️ Servidores Criados: " . implode(", ", $sucess_servers) . "\n"]);
            }
        }
        if (strpos($update->getMessage()->getText(), "/deletar") != false) {
            $usuario = str_replace("/deletar", "", $update->getMessage()->getText());
            $usuario = trim($usuario);
            $sql = "SELECT * FROM ssh_accounts WHERE login = '" . $usuario . "'";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) == 0) {
                $telegram->sendMessage(["chat_id" => $chat_id, "text" => "Usuário inválido, Use /deletar usuario"]);
            } else {
                $row = mysqli_fetch_assoc($result);
                $categoria = $row["categoriaid"];
                $busca_server = mysqli_query($conn, "SELECT * FROM servidores WHERE subid = '" . $categoria . "'");
                while ($row = mysqli_fetch_array($busca_server)) {
                    $servidores[] = $row;
                }
                define("SSH_PORT", 22);
                function trySshConnection($ip, $porta, $usuario, $senha, $tentativas = 3, $intervalo = 2)
                {
                    $ssh = new Net_SSH2($ip, $porta);
                    for ($tentativaAtual = 1; !$ssh->login($usuario, $senha); $tentativaAtual++) {
                        if ($tentativas < $tentativaAtual) {
                            return false;
                        }
                        sleep($intervalo);
                        $ssh = new Net_SSH2($ip, $porta);
                    }
                    return $ssh;
                }
                $sucess_servers = [];
                foreach ($servidores as $servidor) {
                    $ssh = trySshConnection($servidor["ip"], $servidor["porta"], $servidor["usuario"], $servidor["senha"]);
                    if ($ssh) {
                        $ssh->exec("./atlasremove.sh " . $login . " ");
                        $ssh->exec("./atlasremove.sh " . $login . "");
                        $sucess_servers[] = $servidor["nome"];
                        $sucess = true;
                        $ssh->disconnect();
                    }
                }
                if ($sucess) {
                    $sql_conta = "DELETE FROM ssh_accounts WHERE login = '" . $usuario . "'";
                    $result = mysqli_query($conn, $sql_conta);
                    $telegram->sendMessage(["chat_id" => $chat_id, "text" => "✅ Conta deletada com sucesso! \n\n" . "👤 Usuário: " . $usuario . " \n" . "🖥️ Servidores Deletados: " . implode(", ", $sucess_servers) . "\n"]);
                } else {
                    $telegram->sendMessage(["chat_id" => $chat_id, "text" => "❌ Erro ao deletar conta! \n\n" . "👤 Usuário: " . $usuario . " \n"]);
                }
            }
        }
        file_put_contents("last_update_id.txt", $last_update_id);
    }
    sleep(1);
}

?>