#!/bin/bash
subdominio=$1
dominio=$(cat /opt/gestorarquivos/dominio)
tokencf=$(cat /opt/gestorarquivos/tokencf)
pastafile=/tmp/PastaExclui.txt
procurarpasta=$(find /var/www/html/gestoratlas/ -type d -name "$subdominio")
echo $procurarpasta > $pastafile
pastalist=""
/opt/gestorarquivos/excluisub.py $dominio $subdominio $tokencf
for pasta in `cat ${pastafile}` ; do pastalist="${pastalist} ${pasta}" ; done
passdb=$(cat /opt/gestorarquivos/sweb)
for past in $(echo "$pastalist"); do rm -r $past ; done
mysql -h localhost -u root -p$passdb -e "drop database $subdominio"
rm -rf /etc/apache2/sites-available/$subdominio.conf
sudo a2dissite *.conf > /dev/null 2>&1
sudo a2ensite *.conf > /dev/null 2>&1
/etc/init.d/mysql restart > /dev/null 2>&1
systemctl restart apache2 > /dev/null 2>&1
