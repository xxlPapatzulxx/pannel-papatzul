#!/usr/bin/env python3
""" 
Adds DNS A records pointing to a mentioned server using Cloudflare API v4. Edit places necessary. 
Note:
For better codebase privacy/security, refer configuration file for
authentication in python-cloudflare docs. This is for internal usage.
"""
import CloudFlare # pip3 install cloudflare
import sys

def print_help():
    help_string = """
    Adds DNS A records pointing to this server.
    
     USAGE
    =======
    python3 create-dns-record.py [ZONE_NAME] [SUBDOMAIN]
     EXAMPLE (creates subdomain.example.com)
    =======================================
    python3 create-dns-record.py example.com subdomain
    """
    print(help_string)

def return_zone_info(cf, zone_name):
    try:
        zone_info = cf.zones.get(params={'name': zone_name})[0]
    except IndexError:
        print("A zona não existe token!")
        exit(-1)
    return zone_info

def add_record(zone_name, subdomain, ipv6):
    cf = CloudFlare.CloudFlare(token=tokencf)
    zone_info = return_zone_info(cf, zone_name)
    zone_id = zone_info['id']
    dns_record = {'name': subdomain, 'type': 'AAAA', 'proxied': True, 'content': ipv6}
    try:
        r = cf.zones.dns_records.post(zone_id, data=dns_record)
    except CloudFlare.exceptions.CloudFlareAPIError:
        print("Esse subdomínio em IPV6 já existe!")
        exit(-1)
    if r['name'] == subdomain+'.'+zone_name:
        print(r['name'], "IPV6 adicionado com sucesso na FLARE!")
    exit(0)

if __name__ == '__main__':
    try:
        zone_name = sys.argv[1]
        subdomain = sys.argv[2]
        ipv6 = sys.argv[3]
        tokencf = sys.argv[4]
    except IndexError:
        print_help()
    add_record(zone_name, subdomain,
    ipv6)