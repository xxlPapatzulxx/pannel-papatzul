#!/bin/bash
subdominio=$1
tokenp=$2
dominio=$(cat /opt/gestorarquivos/dominio)
passdb=$(cat /opt/gestorarquivos/sweb)
tokencf=$(cat /opt/gestorarquivos/tokencf)
mainiduser=$(tr -dc 0-9 < /dev/urandom | head -c 6)
if ! { curl -4 -s --head --fail https://ipv4.google.com >/dev/null; }; then
sleep 1
else
ipv4=$(wget -qO- ipv4.icanhazip.com)
/opt/gestorarquivos/proipv4.py $dominio $subdominio $ipv4 $tokencf
fi
if ! { curl -6 -s --head --fail https://ipv6.google.com >/dev/null; }; then
sleep 1
else
ipv6=$(wget -qO- ipv6.icanhazip.com)
/opt/gestorarquivos/proipv6.py $dominio $subdominio $ipv6 $tokencf
fi
[[ ! -d /var/www/html/gestoratlas ]] && mkdir /var/www/html/gestoratlas > /dev/null 2>&1
[[ ! -d /var/www/html/gestoratlas/$subdominio ]] && mkdir /var/www/html/gestoratlas/$subdominio > /dev/null 2>&1
cp /root/GestorAtlas.zip /var/www/html/gestoratlas/$subdominio > /dev/null 2>&1
unzip  -o /var/www/html/gestoratlas/$subdominio/GestorAtlas.zip -d /var/www/html/gestoratlas/$subdominio > /dev/null 2>&1
rm /var/www/html/gestoratlas/$subdominio/GestorAtlas.zip > /dev/null 2>&1
chmod 777 -R /var/www/html/gestoratlas > /dev/null 2>&1
sed -i "s;mainiduser;$mainiduser;g" /var/www/html/gestoratlas/$subdominio/bdgestoratlas.sql > /dev/null 2>&1
mysql -u root -p"$passdb" -e "CREATE DATABASE $subdominio;"
mysql -u root -p"$passdb" -e "GRANT ALL PRIVILEGES ON $subdominio.* To 'root'@'localhost' IDENTIFIED BY '$passdb';"
mysql -u root -p"$passdb" -e "FLUSH PRIVILEGES"
mysql -h localhost -u root -p"$passdb" --default_character_set utf8 $subdominio < /var/www/html/gestoratlas/$subdominio/bdgestoratlas.sql > /dev/null 2>&1
rm /var/www/html/gestoratlas/$subdominio/bdgestoratlas.sql > /dev/null 2>&1
accesskeyhash=$(echo $RANDOM | md5sum | head -c 20; echo;)
echo "<?php
date_default_timezone_set('America/Sao_Paulo');
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
ob_start();
session_start();
if (strcmp(basename(\$_SERVER[\"SCRIPT_NAME\"]), basename(__FILE__)) === 0){
header(\"location: /\");
exit;
}
\$accessKEY = '$accesskeyhash'; 
\$dbhost = 'localhost';
\$dbuser = 'root';
\$dbpass = '$passdb';
\$dbname = '$subdominio';
\$_SESSION['token'] = '$tokenp';
?>" > /var/www/html/gestoratlas/$subdominio/atlas/conexao.php
echo '<VirtualHost *:80>

    ServerName '$subdominio'.'$dominio'

    ServerAdmin server@dominio.com

    DocumentRoot /var/www/html/gestoratlas/'$subdominio'

    ErrorLog ${APACHE_LOG_DIR}/error.log

    CustomLog ${APACHE_LOG_DIR}/access.log combined

</VirtualHost>' > /etc/apache2/sites-available/$subdominio.conf
sudo a2dissite *.conf > /dev/null 2>&1
sudo a2ensite *.conf > /dev/null 2>&1
/etc/init.d/mysql restart > /dev/null 2>&1
systemctl restart apache2 > /dev/null 2>&1
