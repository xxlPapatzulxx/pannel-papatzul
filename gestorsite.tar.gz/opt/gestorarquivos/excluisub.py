#!/usr/bin/env python3
""" 
Deletes DNS A record(s) using Cloudflare API v4. Edit places necessary. 
Program will ask for manual confirmation to prevent accidental deletion.

Note:
For better codebase privacy/security, refer configuration file for
authentication in python-cloudflare docs. This is for internal usage.
"""

import CloudFlare  # pip3 install cloudflare
import sys


def print_help():
    help_string = """
    Deletes DNS A records using Cloudflare API v4.
    
     USAGE
    =======
    python3 delete_dns_records.py [Zone Name] [Sub doman]

     EXAMPLE (deletes sub.example.com)
    =======================================
    python3 delete_dns_records.py example.com sub
    """
    print(help_string)


def return_zone_info(cf, zone_name):
    try:
        zone_info = cf.zones.get(params={'name': zone_name})[0]
    except IndexError:
        print("A zona não existe token!")
        exit(-1)
    return zone_info


def delete_record(zone_name, dns_name):
    cf = CloudFlare.CloudFlare(token=tokencf)
    zone_info = return_zone_info(cf, zone_name)
    zone_id = zone_info['id']
    dns_records = cf.zones.dns_records.get(
        zone_id, params={'name': dns_name + '.' + zone_name})
    if len(dns_records) < 1:
        print("Esse subdomínio não existe na FLARE!")
        exit(-1)
    for dns_record in dns_records:
        dns_record_id = dns_record['id']
        r = cf.zones.dns_records.delete(zone_id, dns_record_id)
    print(dns_name + '.' + zone_name, "Subdomínio excluído na FLARE!")
    exit(0)


if __name__ == '__main__':
    try:
        zone_name = sys.argv[1]
        dns_name = sys.argv[2]
        tokencf = sys.argv[3]
    except IndexError:
        print_help()
    delete_record(zone_name, dns_name)