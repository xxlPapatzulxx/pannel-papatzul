#!/bin/bash
[[ ! -d /opt/gestorarquivos/subsite ]] && mkdir /opt/gestorarquivos/subsite
if [ -z "$(ls -A /opt/gestorarquivos/subsite)" ]; then
   echo "Não possui arquivos pra executar!"
else
chmod 777 -R /opt/gestorarquivos
[[ $(ls /opt/gestorarquivos/subsite/ | grep -c '.sh') != '0' ]] && {
for i in $(ls /opt/gestorarquivos/subsite/ | grep '.sh'); do
tempo=$(cat /opt/gestorarquivos/subsite/$i | head -n1)
[[ $(date +%s) -gt $tempo ]] && {
/opt/gestorarquivos/subsite/$i
}
done
}
echo "Arquivos executados com sucesso!"
fi

